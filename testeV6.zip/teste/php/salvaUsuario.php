<?php

$nome  = $_POST['nNome'];
$tipo = $_POST['nTipo'];
$email = $_POST['nEmail'];
$senha = $_POST['nSenha'];
$data = $_POST['nData'];
//$ativo = $_POST['nAtivo'];
$opcao = $_GET['opcao'];
$id    = $_GET['id'];

$setSenha = '';

if($senha != ''){
	$setSenha = "senha = md5('$senha'),";
}

if($_POST['nAtivo'] == 'on'){
	$ativo = 'S';
}else{
	$ativo = 'N';	
}

include("conexao.php");

if($opcao == 'I'){
	$sql = "INSERT INTO usuario (id_tipo_usuario,nome,login,senha,data_nasc,flg_ativo)
			VALUES($tipo,'$nome','$email',md5('$senha'),'$data','$ativo');";
}elseif($opcao == 'A'){
	$sql = "UPDATE usuario
			SET nome = '$nome',
				id_tipo_usuario = $tipo,
				login = '$email',
				$setSenha
				data_nasc = '$data',
				flg_ativo = '$ativo'
			WHERE id_usuario = $id;";
}elseif($opcao =='E'){
    $sql = "DELETE FROM usuario WHERE id_usuario = $id;";
}

$result = mysqli_query($conn,$sql);
mysqli_close($conn);

header("location: ../usuarios.php");

?>