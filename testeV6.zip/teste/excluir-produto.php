<?php
include("php/funcoes.php");
//Buscar os dados do usuário do ID recebido por GET
$produto = buscaProdutoId($_GET['id']);

?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Excluir Produto</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<form method="POST" action="php/salvarProduto.php?opcao=E&id=<?php echo $_GET['id'];?>">
			
			<p>
				<label>
                    Deseja realmente excluir o produto <?php echo $produto['descricao'];?>?
                </label>
			</p>

			<a href="produtos.php">			
			<input type="button" value="Não">
            </a>

			<input type="submit" value="Sim">
		
		</form>
		
	</body>
	
</html>