<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Menu</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<h5>
			<?php if($_SESSION['tipo_usuario'] == 1){?>
            <a href="usuarios.php">Usuários</a>
            |
			<?php }?>
            <a href="index.php">Sair</a>
            |
            <a href="produtos.php">Produtos</a>
        </h5>
		
		</form>
		
	</body>
	
</html>