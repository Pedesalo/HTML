<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>PHP</title>
		<meta charset="UTF-8">

		<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css">
		
	</head>
    <div class="alert alert-primary" role="alert">
    Um simples alerta primary. Olha só!
    </div>
    
    <button type="button" class="btn btn-primary">
    Notificações <span class="badge badge-light">4</span>
    </button>


		<script src="dist/js/bootstrap.min.js"></script>
	</body>
	
</html>