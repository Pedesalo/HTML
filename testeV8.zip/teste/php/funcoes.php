<?php
include("funcaoUsuario.php");
include("funcaoProduto.php");
include("funcaoTipoUsuario.php");

//Descrição de uma flag de ativo	
function descrFlag($flag){
	if($flag == 'S'){
		return 'Sim';		
	}else{
		return 'Não';
	}		
}

//Próximo ID de uma tabela

function proximoID($tabela,$campo){
	$id=0;

	include("conexao.php");
	
	$sql = "SELECT MAX($campo) AS ID FROM $tabela;";
		
	$result = mysqli_query($conn,$sql);
	mysqli_close($conn);
	
	if(mysqli_num_rows($result) > 0){
		foreach($result as $campo){
			$id = $campo['ID'];
		}
	}
	return $id + 1;
}
?>