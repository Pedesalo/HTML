<?php

$nome  = $_POST['nNome'];
$tipo = $_POST['nTipo'];
$email = $_POST['nEmail'];
$senha = $_POST['nSenha'];
$data = $_POST['nData'];
$opcao = $_GET['opcao'];
$id    = $_GET['id'];

include('funcoes.php');

//var_dump(proximoID('usuario','id_usuario'));
//die();

$setSenha = '';

if($senha != ''){
	$setSenha = "senha = md5('$senha'),";
}

if($_POST['nAtivo'] == 'on'){
	$ativo = 'S';
}else{
	$ativo = 'N';	
}

include("conexao.php");

if($opcao == 'I'){
	$id = proximoID('usuario','id_usuario');

	$sql = "INSERT INTO usuario (id_usuario,id_tipo_usuario,nome,login,senha,data_nasc,flg_ativo)
			VALUES($id,$tipo,'$nome','$email',md5('$senha'),'$data','$ativo');";
}elseif($opcao == 'A'){
	$sql = "UPDATE usuario
			SET nome = '$nome',
				id_tipo_usuario = $tipo,
				login = '$email',
				$setSenha
				data_nasc = '$data',
				flg_ativo = '$ativo'
			WHERE id_usuario = $id;";
}elseif($opcao =='E'){
    $sql = "DELETE FROM usuario WHERE id_usuario = $id;";
}

$result = mysqli_query($conn,$sql);
mysqli_close($conn);

//IMAGEM
if($_FILES['nFoto']['tmp_name'] !=""){
	//GRAVA A EXTENSÃO DO ARQUIVO
	$extensao = pathinfo($_FILES['nFoto']['name'], PATHINFO_EXTENSION);

	//	NOVO NOME DO ARQUIVO
	$novoNome = md5($_FILES['nFoto']['name']).'.'.$extensao;

	//Verificar se o diretório existe, ou criar a pasta
	if(is_dir('../img/')){
		//Existe
		$diretorio ='../img/';

	}else{
		//Criar pq não existe
		$diretorio =mkdir('../img/');
	}

	//Cria uma cópia do arquivo local na pasta do projeto
	move_uploaded_file($_FILES['nFoto']['tmp_name'],$diretorio.$novoNome);

	//Caminho que será salvo no banco de dados
	$dirImagem ='img/'.$novoNome;

	include('conexao.php');
	$sql = "UPDATE usuario
	SET foto = '.$dirImagem'
	WHERE id_usuario = $id;";
	$result = mysqli_query($conn,$sql);
	mysqli_close($conn);


}

header("location: ../usuarios.php");

?>