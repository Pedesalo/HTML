<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Novo Produto</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
	<a href="produtos.php">Voltar</a>
		<form method="POST" action="php/salvarProduto.php?opcao=I">
			
			<p>
				<label>Descrição:</label>
				<input type="text" name="nDescricao" maxlength="50" required>
			</p>
			<p>
				<label>Quantidade:</label>
				<input type="number" name="nQuantidade" >
			</p>
			<p>
				<label>Valor Unitário:</label>
				<input type="number" step=".01" name="nUnidade">
			</p>
			<p>
				<input type="checkbox" name="nAtivo" id="iAtivo">
				<label for="iAtivo">Produto Ativo</label>
			</p>
						
			<input type="reset" value="Limpar">
			<input type="submit" value="Salvar">
		
		</form>
		
	</body>
	
</html>