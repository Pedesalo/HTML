<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>PHP</title>
		<meta charset="UTF-8">

		<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css">
		
	</head>
	
	<body>
		
		<form method="POST" action="php/validacao.php">
			
			<p>
				<label class="text-">Usuário:</label>
				<input type="email" name="nEmail">
			</p>
			<p>
				<label>Senha:</label>
				<input type="password" name="nSenha">
			</p>
						
			<input type="submit">
		
		</form>
		

		<script src="dist/js/bootstrap.min.js"></script>
	</body>
	
</html>