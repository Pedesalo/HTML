<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Menu</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<h5>
            <a href="usuarios.php">Usuários</a>
            |
            <a href="index.php">Sair</a>
            |
            <a href="produtos.php">Produtos</a>
        </h5>
		
		</form>
		
	</body>
	
</html>