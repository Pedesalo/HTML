<?php

$nome  = $_POST['nNome'];
$email = $_POST['nEmail'];
$senha = $_POST['nSenha'];
//$ativo = $_POST['nAtivo'];
$opcao = $_GET['opcao'];
$id    = $_GET['id'];

$setSenha = '';

if($senha != ''){
	$setSenha = "senha = md5('$senha'),";
}

if($_POST['nAtivo'] == 'on'){
	$ativo = 'S';
}else{
	$ativo = 'N';	
}

include("conexao.php");

if($opcao == 'I'){
	$sql = "INSERT INTO usuario (nome,login,senha,flg_ativo)
			VALUES('$nome','$email',md5('$senha'),'$ativo');";
}elseif($opcao == 'A'){
	$sql = "UPDATE usuario
			SET nome = '$nome',
				login = '$email',
				$setSenha
				flg_ativo = '$ativo'
			WHERE id_usuario = $id;";
}elseif($opcao =='E'){
    $sql = "DELETE FROM usuario WHERE id_usuario = $id;";
}

$result = mysqli_query($conn,$sql);
mysqli_close($conn);

header("location: ../usuarios.php");

?>