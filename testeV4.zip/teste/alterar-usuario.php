<?php
include("php/funcoes.php");
//Buscar os dados do usuário do ID recebido por GET
$usuario = buscaUsuarioId($_GET['id']);

$flagAtivo = '';
if($usuario['flg_ativo'] == 'S'){
	$flagAtivo = 'checked';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Alterar Usuário</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<form method="POST" action="php/salvaUsuario.php?opcao=A&id=<?php echo $_GET['id'];?>">
			
			<p>
				<label>Nome:</label>
				<input type="text" value="<?php echo $usuario['nome'];?>" name="nNome" maxlength="80" required>
			</p>
			<p>
				<label>Login:</label>
				<input type="email" value="<?php echo $usuario['login'];?>" name="nEmail" maxlength="60" required>
			</p>
			<p>
				<label>Senha:</label>
				<input type="password" value="" name="nSenha" maxlength="8">
			</p>
			<p>
				<input type="checkbox" name="nAtivo" id="iAtivo" <?php echo $flagAtivo;?>>
				<label for="iAtivo">Usuário Ativo</label>
			</p>
						
			<input type="reset" value="Limpar">
			<input type="submit" value="Salvar">
		
		</form>
		
	</body>
	
</html>