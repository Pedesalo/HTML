<?php
include("php/funcoes.php");
//Buscar os dados do usuário do ID recebido por GET
$usuario = buscaProdutoId($_GET['id']);

$flagAtivo = '';
if($usuario['flg_ativo'] == 'S'){
	$flagAtivo = 'checked';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Alterar Produto</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<form method="POST" action="php/salvaProduto.php?opcao=A&id=<?php echo $_GET['id'];?>">
			
			<p>
				<label>Descrição:</label>
				<input type="text" value="<?php echo $produtos['descricao'];?>" name="nDescricao" maxlength="50" required>
			</p>
			<p>
				<label>Quantidade:</label>
				<input type="number" value="<?php echo $produtos['quantidade'];?>" name="nQuantidade">
			</p>
			<p>
				<label>Valor Unitário:</label>
				<input type="number" step=.01 value="<?php echo $produtos['valor_unitario'];?>" name="nUnidade">
			</p>
			<p>
				<input type="checkbox" name="nAtivo" id="iAtivo" <?php echo $flagAtivo;?>>
				<label for="iAtivo">Produto Ativo</label>
			</p>
						
			<input type="reset" value="Limpar">
			<input type="submit" value="Salvar">
		
		</form>
		
	</body>
	
</html>