<?php
include("funcaoUsuario.php");
include("funcaoProduto.php");

//Descrição de uma flag de ativo	
function descrFlag($flag){
	if($flag == 'S'){
		return 'Sim';		
	}else{
		return 'Não';
	}		
}	
?>