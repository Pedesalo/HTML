<?php
	include("php/funcoes.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Produtos</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		<h5><a href="menu.php">Voltar</a></h5>
		<h4>Produdos</h4>
		
		<p>
			<a href="novo-produto.php">
				<input type="button" value="Novo Produto">
			</a>
		</p>
		
		<table border="1">
		
			<tr>
				<th>ID</th>
				<th>Descrição</th>
				<th>Quantidade</th>
				<th>Valor Unitário</th>
				<th>Ativo</th>
				<th>Ações</th>
			</tr>
			
			<?php echo listaProdutos();?>
			
			<!--
			<tr>
				<td>id_usuario</td>
				<td>nome</td>
				<td>login</td>
				<td>senha</td>
				<td>Alterar | Excluir</td>
			</tr>
			-->
		</table>
		
	</body>
	
</html>