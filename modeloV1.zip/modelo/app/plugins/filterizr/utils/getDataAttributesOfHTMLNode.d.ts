import { Dictionary } from '../types/interfaces/Dictionary';
export declare function getDataAttributesOfHTMLNode(node: Element): Dictionary;
