<?php

    //Abrir conexão com o Banco de Dados
    $conn = mysqli_connect("localhost","root","","modelo") or die("Falha: " . mysqli_connect_error());

?>