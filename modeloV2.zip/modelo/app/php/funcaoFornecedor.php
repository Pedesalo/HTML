<?php
//Função para listar todos os usuários
function listaFornecedor(){

    include("conexao.php");
    $sql = "SELECT * FROM fornecedor ORDER BY id_fornecedor;";
            
    $result = mysqli_query($conn,$sql);
    mysqli_close($conn);

    $lista = '';

    //Validar se tem retorno do BD
    if (mysqli_num_rows($result) > 0) {        
        
        foreach ($result as $coluna) {

            //***Verificar os dados da consulta SQL
            $lista .= 
            '<tr>'
                .'<td>'.$coluna["id_fornecedor"].'</td>'
                .'<td>'.$coluna["nome_fantasia"].'</td>'
                .'<td>'.$coluna["cnpj"].'</td>'
                .'<td>'.$coluna["cidade"].'</td>'
                .'<td>'.$coluna["uf"].'</td>'
                .'<td>'.$coluna["flg_ativo"].'</td>'
                .'<td>'
                    .'<div class="row" align="center">'
                        .'<div class="col-6">'
                            .'<a href="#modalEditFornecedor'.$coluna["id_fornecedor"].'" data-toggle="modal">'
                                .'<h6><i class="fas fa-edit text-info" data-toggle="tooltip" title="Alterar Fornecedor"></i></h6>'
                            .'</a>'
                        .'</div>'
                        
                        .'<div class="col-6">'
                            .'<a href="#modalDeleteFornecedor'.$coluna["id_fornecedor"].'" data-toggle="modal">'
                                .'<h6><i class="fas fa-trash text-danger" data-toggle="tooltip" title="Excluir Fornecedor"></i></h6>'
                            .'</a>'
                        .'</div>'
                    .'</div>'
                .'</td>'
            .'</tr>'
            
            .'<div class="modal fade" id="modalEditFornecedor'.$coluna["id_fornecedor"].'">'
                .'<div class="modal-dialog modal-lg">'
                    .'<div class="modal-content">'
                        .'<div class="modal-header bg-info">'
                            .'<h4 class="modal-title">Alterar Fornecedor</h4>'
                            .'<button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">'
                                .'<span aria-hidden="true">&times;</span>'
                            .'</button>'
                        .'</div>'
            .'<div class="modal-body">'
            .'<form method="POST" action="php/salvarFornecedor.php?funcao=A&codigo'.$coluna["id_fornecedor"].'" enctype="multipart/form-data">     '         
                
            .'<div class="row">'
            .'<div class="col-6">'
            .'<div class="form-group">'
            .'<label for="iRazaoSocial">Razão Social:</label>'
            .'<input type="text" class="form-control" id="iRazaoSocial" '.$coluna["id_fornecedor"].' name="nRazaoSocial" maxlength="80">'
            .'</div>'
            .'</div>'

            .'<div class="col-6">'
            .'<div class="form-group">'
            .'<label for="iNomeFantasia">Nome Fantasia:</label>'
            .'<input type="text" class="form-control" id="iNomeFantasia" '.$coluna["id_fornecedor"].' name="nNomeFantasia" maxlength="50">'
            .'</div>'
            .'</div>'

            .'<div class="row">'
            .'<div class="col-6">'
            .'<div class="form-group">'
            .'<label for="iCNPJ">CNPJ:</label>'
            .'<input type="text" class="form-control" id="iCNPJ" '.$coluna["id_fornecedor"].' name="nCNPJ" maxlength="20">'
            .'</div>'
            .'</div>'
              
            .'<div class="col-12">'
            .'<div class="form-group">'
            .'<label for="iLogo">Logo:</label>'
            .'<input type="file" class="form-control" id="iLogo" '.$coluna["id_fornecedor"].' name="nLogo" accept="image/*">'
            .'</div>'
            .'</div>'
                
            .'<div class="col-12">'
            .'<div class="form-group">'
            .'<input type="checkbox" id="iAtivo" '.$coluna["id_fornecedor"].' name="nAtivo">'
            .'<label for="iAtivo">Fornecedor Ativo</label>'
            .'</div>'
            .'</div>'

            .'<div class="col-3">'
            .'<div class="form-group">'
            .'<label>CEP</label>'
            .'<input required name="CEP" type="text" '.$coluna["id_fornecedor"].' class="form-control cep">'
            .'</div>'
            .'</div>'
               
            .'<div class="col-9">'
            .'<div class="form-group">'
            .'<label>Endereço</label>'
            .'<input required name="Endereco" type="text" '.$coluna["id_fornecedor"].' class="form-control">'
            .'</div>'
            .'</div>'

            .'<div class="col-3">'
            .'<div class="form-group">'
            .'<label>Número</label>'
            .'<input required name="Numero" type="text" '.$coluna["id_fornecedor"].' maxlength="8" class="form-control">'
            .'</div>'
            .'</div>'

            .'<div class="col-9">'
            .'<div class="form-group">'
            .'<label>Complemento</label>'
            .'<input name="Complemento" type="text" '.$coluna["id_fornecedor"].' maxlength="50" class="form-control">'
            .'</div>'
            .'</div>'

            .'<div class="col-5">'
            .'<div class="form-group">'
            .'<label>Bairro</label>'
            .'<input required name="Bairro" type="text" '.$coluna["id_fornecedor"].' class="form-control">'
            .'</div>'
            .'</div>'
                 
            .'<div class="col-5">'
            .'<div class="form-group">'
            .'<label>Cidade</label>'
            .'<input required name="Cidade" type="text" '.$coluna["id_fornecedor"].' class="form-control">'
            .'</div>'
            .'</div>'

            .'<div class="col-2">'
            .'<div class="form-group">'
            .'<label>UF</label>'
            .'<input required name="UF" type="text" '.$coluna["id_fornecedor"].' class="form-control">'
            .'</div>'
            .'</div>'

            .'</div>'

                .'<div class="modal-footer">'
                  .'<button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>'
                  .'<button type="submit" class="btn btn-success">Salvar</button>'
                .'</div>'
                
              .'</form>'

           .' </div>'
                    .'</div>'
                .'</div>'
            .'</div>'; 
                      
        }    
    }
    
    return $lista;
}

function proxIdFornecedor(){

    $id = "";

    include("conexao.php");
    $sql = "SELECT MAX(id_fornecedor) AS Maior FROM fornecedor;";        
    $result = mysqli_query($conn,$sql);
    mysqli_close($conn);

    //Validar se tem retorno do BD
    if (mysqli_num_rows($result) > 0) {
                
        $array = array();
        
        while ($linha = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            array_push($array,$linha);
        }
        
        foreach ($array as $coluna) {            
            //***Verificar os dados da consulta SQL
            $id = $coluna["Maior"] + 1;
        }
}
}
?>