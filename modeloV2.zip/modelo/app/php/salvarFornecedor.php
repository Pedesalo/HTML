<?php

    include('funcoes.php');

    $razao_social = $_POST["nRazaoSocial"];
    $nome_fantasia = $_POST["nNomeFantasia"];
    $cnpj = $_POST["nCNPJ"];
    $endereco = $_POST["Endereco"];
    $numero = $_POST["Numero"];
    $complemento = $_POST["Complemento"];
    $bairro = $_POST["Bairro"];
    $cidade = $_POST["Cidade"];
    $uf = $_POST["UF"];
    $cep = $_POST["CEP"];
    $logo = $_POST["nLogo"];

    $funcao = $_GET["funcao"];
    $idFornecedor   = $_GET["codigo"];

    include("conexao.php");

    //Validar se é Inclusão ou Alteração
    if($funcao == "I"){

        //Busca o próximo ID na tabela
        $idFornecedor = proxIdFornecedor();


        //INSERT
        $sql = "INSERT INTO fornecedor (id_fornecedor,razao_social,nome_fantasia,cnpj,endereco,numero,complemento,bairro,cidade,uf,cep,logo,flg_ativo) "
                ." VALUES (".$idFornecedor.","
                ."'$razao_social',"
                ."'$nome_fantasia',"
                ."'$cnpj',"
                ."'$endereco',"
                ."'$numero',"
                ."'$complemento',"
                ."'$bairro',"
                ."'$cidade',"
                ."'$uf',"
                ."'$cep',"
                ."'$logo',"
                ."'$ativo');";


    }elseif($funcao == "A"){
        //UPDATE

        $sql = "UPDATE fornecedor "
                ." SET razao_social = $razao_social, "
                    ." nome_fantasia = '$nome_fantasia', "
                    ." cnpj = '$cnpj', "
                    ." endereco = '$endereco', "
                    ." numero = '$numero', "
                    ." complemento = '$complemento', "
                    ." bairro = '$bairro', "
                    ." cidade = '$cidade', "
                    ." uf = '$uf', "
                    ." cep = '$cep', "
                    ." logo = '$logo', "
                    ." flg_ativo = '$ativo',"
                ." WHERE id_fornecedor = $idFornecedor;";

    }elseif($funcao == "D"){
        //DELETE
        $sql = "DELETE FROM usuarios "
                ." WHERE idUsuario = $idUsuario;";
    }

    $result = mysqli_query($conn,$sql);
    mysqli_close($conn);


    //VERIFICA SE TEM IMAGEM NO INPUT
    if($_FILES['Foto']['tmp_name'] != ""){

        //Usar o mesmo nome do arquivo original
        //$nomeArq = $_FILES['Foto']['name'];
        //...
        //OU
        //Pega a extensão do arquivo e cria um novo nome pra ele (MD5 do nome original)
        $extensao = pathinfo($_FILES['Foto']['name'], PATHINFO_EXTENSION);
        $novoNome = md5($_FILES['Foto']['name']).'.'.$extensao;        
        
        //Verificar se o diretório existe, ou criar a pasta
        if(is_dir('../dist/img/')){
            //Existe
            $diretorio = '../dist/img/';
        }else{
            //Criar pq não existe
            $diretorio = mkdir('../dist/img/');
        }

        //Cria uma cópia do arquivo local na pasta do projeto
        move_uploaded_file($_FILES['Foto']['tmp_name'], $diretorio.$novoNome);

        //Caminho que será salvo no banco de dados
        $dirImagem = 'dist/img/'.$novoNome;

        include("conexao.php");
        //UPDATE
        $sql = "UPDATE usuarios "
                ." SET Foto = '$dirImagem' "
                ." WHERE idUsuario = $idUsuario;";
        $result = mysqli_query($conn,$sql);
        mysqli_close($conn);
    }

    header("location: ../usuarios.php");

?>