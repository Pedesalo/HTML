function resultado(p1,p2){
    var msg = "";
    if (p1>p2){
        msg = "O primeiro valor � maior que o segundo";
    }else if (p1<p2){
        msg = "O segundo valor � maior que o primeiro";
    }else 
        msg = "Os valores s�o iguais"
    return msg;
}
