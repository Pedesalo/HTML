<?php
include("php/funcoes.php")
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		
		<title>Novo Usuário</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
	<a href="usuarios.php">Voltar</a>
		<form method="POST" action="php/salvaUsuario.php?opcao=I">
			
			<p>
				<label>Nome:</label>
				<input type="text" name="nNome" maxlength="80" required>
			</p>
			<p>
				<label for="iTipo">Tipo de Usuário</label>
				<select name="nTipo" id="iTipo" required>
				<option value="">Selecione...</option>
					<?php echo optionTipoUsuario();?>
				</select>

			</p>
			<p>
				<label>Login:</label>
				<input type="email" name="nEmail" maxlength="60" required>
			</p>
			<p>
				<label>Senha:</label>
				<input type="password" name="nSenha" maxlength="8" required>
			</p>
			<p>
				<input type="checkbox" name="nAtivo" id="iAtivo">
				<label for="iAtivo">Usuário Ativo</label>
			</p>
						
			<input type="reset" value="Limpar">
			<input type="submit" value="Salvar">
			
		</form>
		
	</body>
	
</html>