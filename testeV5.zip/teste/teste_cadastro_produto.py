from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("http://localhost:8080/teste/")

iLogin = driver.find_element(By.ID, "iLogin")
iLogin.send_keys("ckatzer@gmail.com")

iSenha = driver.find_element(By.ID, "iSenha")
iSenha.send_keys("onetwothreedrink")

submit_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
submit_button.click()

time.sleep(3)

driver.quit()