<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>PHP</title>
		<meta charset="UTF-8">
		
	</head>
	
	<body>
		
		<form method="POST" action="php/validacao.php">
			
			<p>
				<label>Usuário:</label>
				<input type="email" name="nEmail">
			</p>
			<p>
				<label>Senha:</label>
				<input type="password" name="nSenha">
			</p>
						
			<input type="submit">
		
		</form>
		
	</body>
	
</html>