<?php
function buscaTipoUsuarioId($id){
    include("conexao.php");	
	$sql = "SELECT * 
            FROM tipo_usuario 
            WHERE id_tipo_usuario = $id;";
	
	$result = mysqli_query($conn,$sql);
	mysqli_close($conn);
	
	if(mysqli_num_rows($result) > 0){
		foreach($result as $campo){
			
		}
	}	
	return $campo;


}


?>